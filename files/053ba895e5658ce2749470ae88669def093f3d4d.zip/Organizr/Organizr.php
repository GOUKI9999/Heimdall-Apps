<?php

namespace App\SupportedApps\Organizr;

class Organizr extends \App\SupportedApps
{
}
