<?php

namespace App\SupportedApps\TwoFAuth;

class TwoFAuth extends \App\SupportedApps
{
}
