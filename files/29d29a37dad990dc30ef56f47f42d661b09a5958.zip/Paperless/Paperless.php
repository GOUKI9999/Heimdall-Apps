<?php

namespace App\SupportedApps\Paperless;

class Paperless extends \App\SupportedApps
{
}
