<ul class="livestats">
    <li>
        <span class="title">Documents</span>
        <strong>{!! $documentCount !!}</strong>
    </li>
    <li>
        <span class="title">Inbox</span>
        <strong>{!! $documentsInbox !!}</strong>
    </li>
</ul>
