<?php

namespace App\SupportedApps\Portall;

class Portall extends \App\SupportedApps
{
}
