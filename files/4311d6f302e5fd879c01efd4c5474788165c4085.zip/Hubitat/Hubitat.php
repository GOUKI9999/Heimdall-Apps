<?php

namespace App\SupportedApps\Hubitat;

class Hubitat extends \App\SupportedApps
{
}
