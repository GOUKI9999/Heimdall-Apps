<ul class="livestats">
    <li>
        <span class="title">{!! $first_stat_label !!}</span>
        <strong>{!! $first_stat_value !!}</strong>
    </li>
    <li>
        <span class="title">{!! $second_stat_label !!}</span>
        <strong>{!! $second_stat_value !!}</strong>
    </li>
</ul>
