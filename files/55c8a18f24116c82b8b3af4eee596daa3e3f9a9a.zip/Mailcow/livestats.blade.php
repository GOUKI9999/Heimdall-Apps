<ul class="livestats">
    <li>
        <span class="title">Mailboxes</span>
        <strong>{!! $mailboxes !!}</strong>
    </li>
    <li>
        <span class="title">Domains</span>
        <strong>{!! $domains !!}</strong>
    </li>
    <li>
        <span class="title">Queue</span>
        <strong>{!! $queue !!}</strong>
    </li>
</ul>
