<?php

namespace App\SupportedApps\FirefoxSend;

class FirefoxSend extends \App\SupportedApps
{
}
