<?php

namespace App\SupportedApps\Radicale;

class Radicale extends \App\SupportedApps
{
}
