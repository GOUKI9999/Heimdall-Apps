<?php

namespace App\SupportedApps\CrontabUI;

class CrontabUI extends \App\SupportedApps
{
}
