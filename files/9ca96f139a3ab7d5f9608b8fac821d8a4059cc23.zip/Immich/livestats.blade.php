<ul class="livestats">
    <li>
        <span class="title">Pics</span>
        <strong>{!! $photos !!}</strong>
    </li>
    <li>
        <span class="title">Vids</span>
        <strong>{!! $videos !!}</strong>
    </li>
    <li>
        <span class="title">Usage</span>
        <strong>{!! $usage !!}</strong>
    </li>
</ul>
