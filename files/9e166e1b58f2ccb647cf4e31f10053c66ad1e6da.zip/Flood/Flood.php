<?php

namespace App\SupportedApps\Flood;

class Flood extends \App\SupportedApps
{
}
