<?php

namespace App\SupportedApps\ProxmoxBackupServer;

class ProxmoxBackupServer extends \App\SupportedApps
{
}
