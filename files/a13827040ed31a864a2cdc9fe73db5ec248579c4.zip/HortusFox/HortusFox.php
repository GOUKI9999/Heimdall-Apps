<?php

namespace App\SupportedApps\HortusFox;

class HortusFox extends \App\SupportedApps
{
}
