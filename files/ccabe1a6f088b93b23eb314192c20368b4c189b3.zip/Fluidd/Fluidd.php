<?php

namespace App\SupportedApps\Fluidd;

class Fluidd extends \App\SupportedApps
{
}
