<?php

namespace App\SupportedApps\LibreNMS;

class LibreNMS extends \App\SupportedApps
{
}
