<?php

namespace App\SupportedApps\ntfy;

class ntfy extends \App\SupportedApps // phpcs:ignore
{
}
