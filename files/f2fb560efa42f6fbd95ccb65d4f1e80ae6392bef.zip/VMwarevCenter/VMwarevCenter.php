<?php

namespace App\SupportedApps\VMwarevCenter;

class VMwarevCenter extends \App\SupportedApps
{
}
