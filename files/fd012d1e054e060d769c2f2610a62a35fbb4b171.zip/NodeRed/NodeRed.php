<?php

namespace App\SupportedApps\NodeRed;

class NodeRed extends \App\SupportedApps
{
}
